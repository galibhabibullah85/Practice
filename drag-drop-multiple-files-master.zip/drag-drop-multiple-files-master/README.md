# drag-drop-multiple-files
Drag and drop multiple file upload using jQuery, Ajax, and PHP

## Documentation

[https://www.cluemediator.com/drag-and-drop-multiple-file-upload-using-jquery-ajax-and-php](https://www.cluemediator.com/drag-and-drop-multiple-file-upload-using-jquery-ajax-and-php)

## Connect with us

Website: [Clue Mediator](https://www.cluemediator.com)  
Like us on [Facebook](https://www.facebook.com/thecluemediator)  
Follow us on [Twitter](https://twitter.com/cluemediator)  
Join us on [Telegram](https://t.me/cluemediator)
